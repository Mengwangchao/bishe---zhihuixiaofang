//
//  Intelligent_fire_protection_2Tests.m
//  Intelligent_fire_protection_2Tests
//
//  Created by 王声䘵 on 2021/6/2.
//

#import <XCTest/XCTest.h>

@interface Intelligent_fire_protection_2Tests : XCTestCase

@end

@implementation Intelligent_fire_protection_2Tests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
