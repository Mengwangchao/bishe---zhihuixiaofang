//
//  QRCodeScanningViewController.h
//  Intelligent_fire_protection_2
//
//  Created by 王声䘵 on 2021/6/16.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#define MAINWINDOWSWIDTH [[UIScreen mainScreen] bounds].size.width
#define MAINWINDOWSHEIGHT [[UIScreen mainScreen] bounds].size.height
NS_ASSUME_NONNULL_BEGIN

@interface QRCodeScanningViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
