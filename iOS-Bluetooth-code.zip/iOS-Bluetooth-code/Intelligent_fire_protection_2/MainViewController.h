//
//  MainViewController.h
//  Intelligent_fire_protection_2
//
//  Created by 王声䘵 on 2021/6/17.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainViewController : UITabBarController

@end

NS_ASSUME_NONNULL_END
