//
//  AppDelegate.h
//  Intelligent_fire_protection
//
//  Created by 王声䘵 on 2021/3/9.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong)UIWindow *window;

@end

