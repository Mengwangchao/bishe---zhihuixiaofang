//
//  ViewController.h
//  Intelligent_fire_protection_2
//
//  Created by 王声䘵 on 2021/6/2.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

